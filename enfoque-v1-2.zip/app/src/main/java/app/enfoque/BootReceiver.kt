package app.enfoque

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Al reiniciar el teléfono, vuelve a programar el recordatorio diario. */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Reminder.schedule(context)
        }
    }
}
