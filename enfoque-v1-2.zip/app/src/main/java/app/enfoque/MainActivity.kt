package app.enfoque

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Base64
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/**
 * Pantalla única: muestra la interfaz web (assets/index.html) dentro de un WebView
 * y le ofrece un puente "Android" para listar apps, bloquear y programar avisos.
 */
class MainActivity : Activity() {

    private lateinit var web: WebView
    private var pageReady = false
    private var pending: Triple<String, String, Long>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        web = WebView(this)
        web.setBackgroundColor(BG)
        setContentView(web)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
                pending?.let { sendBlocked(it.first, it.second, it.third) }
                pending = null
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        readIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        readIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        foreground = true
        if (pageReady) js("window.__native && window.__native.onResume()")
    }

    override fun onPause() {
        foreground = false
        super.onPause()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Minimiza en lugar de cerrar, para no perder la sesión en curso.
        moveTaskToBack(true)
    }

    override fun onDestroy() {
        val p = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        // En modo estricto el bloqueo sigue aunque cierres la app; si no, termina al cerrarla.
        if (!p.getBoolean("strict", false)) {
            p.edit().putLong("endAt", 0L).apply()
        }
        web.destroy()
        super.onDestroy()
    }

    private fun readIntent(i: Intent?) {
        val pkg = i?.getStringExtra("blocked") ?: return
        val reason = i.getStringExtra("reason") ?: "session"
        val until = i.getLongExtra("until", 0L)
        i.removeExtra("blocked")
        if (pageReady) sendBlocked(pkg, reason, until) else pending = Triple(pkg, reason, until)
    }

    private fun sendBlocked(pkg: String, reason: String, until: Long) {
        js(
            "window.__native && window.__native.onBlocked(" +
                JSONObject.quote(pkg) + "," + JSONObject.quote(reason) + "," + until + ")"
        )
    }

    private fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    private fun serviceEnabled(): Boolean {
        val list = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return list.split(':').any {
            val c = ComponentName.unflattenFromString(it)
            c != null && c.packageName == packageName && c.className == BlockService::class.java.name
        }
    }

    private fun endIntent(title: String, text: String): Intent {
        return Intent(this, EndReceiver::class.java).putExtra("title", title).putExtra("text", text)
    }

    inner class Bridge {

        /** Lee las apps instaladas (con icono) y las envía a la página por lotes. */
        @JavascriptInterface
        fun requestApps() {
            Thread {
                val pm = packageManager
                val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                val items = pm.queryIntentActivities(launch, 0)
                    .filter { it.activityInfo.packageName != packageName }
                    .distinctBy { it.activityInfo.packageName }
                    .sortedBy { it.loadLabel(pm).toString().lowercase() }
                val batches = items.chunked(20)
                if (batches.isEmpty()) {
                    js("window.__native.onApps([], true)")
                }
                batches.forEachIndexed { index, batch ->
                    val arr = JSONArray()
                    for (ri in batch) {
                        val o = JSONObject()
                        o.put("id", ri.activityInfo.packageName)
                        o.put("name", ri.loadLabel(pm).toString())
                        o.put("icon", iconData(ri.loadIcon(pm)))
                        arr.put(o)
                    }
                    val last = index == batches.size - 1
                    js("window.__native.onApps(" + arr.toString() + "," + last + ")")
                }
            }.start()
        }

        @JavascriptInterface
        fun isBlockingEnabled(): Boolean = serviceEnabled()

        @JavascriptInterface
        fun openAccessibilitySettings() {
            runOnUiThread {
                try {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun openAppInfo() {
            runOnUiThread {
                try {
                    startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                    )
                } catch (e: Exception) {
                }
            }
        }

        /**
         * Empieza a bloquear. pkgsJson: arreglo JSON de paquetes. endAt: hora de fin en milisegundos.
         * strict: "1" si el modo estricto está activado.
         */
        @JavascriptInterface
        fun startBlock(pkgsJson: String, endAt: String, strict: String) {
            val end = endAt.toDoubleOrNull()?.toLong() ?: 0L
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("pkgs", pkgsJson)
                .putLong("endAt", end)
                .putBoolean("strict", strict == "1")
                .apply()
            runOnUiThread { window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
        }

        @JavascriptInterface
        fun stopBlock() {
            val p = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val strict = p.getBoolean("strict", false)
            val end = p.getLong("endAt", 0L)
            // En modo estricto no se puede cortar el bloqueo antes de tiempo.
            if (strict && end - System.currentTimeMillis() > 2000L) return
            p.edit().putLong("endAt", 0L).putBoolean("strict", false).apply()
            runOnUiThread { window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
        }

        /** Guarda el horario de bloqueo (JSON con on, from, to, days y pkgs). */
        @JavascriptInterface
        fun setSchedule(json: String) {
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("sched", json).apply()
        }

        /** Programa el aviso de fin de sesión o de descanso. */
        @JavascriptInterface
        fun scheduleEnd(endAt: String, title: String, text: String) {
            val t = endAt.toDoubleOrNull()?.toLong() ?: return
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                this@MainActivity, 7, endIntent(title, text),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
        }

        @JavascriptInterface
        fun cancelEnd() {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                this@MainActivity, 7, endIntent("", ""),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_NO_CREATE
            )
            if (pi != null) {
                am.cancel(pi)
                pi.cancel()
            }
        }

        /** Activa o desactiva el recordatorio diario. minutes: minutos desde las 00:00. */
        @JavascriptInterface
        fun setReminder(on: String, minutes: String) {
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean("remindOn", on == "1")
                .putInt("remindAt", minutes.toIntOrNull() ?: (19 * 60))
                .apply()
            Reminder.schedule(this@MainActivity)
        }

        /** Anota el día (aaaa-mm-dd) en que completaste algo, para no avisarte ese día. */
        @JavascriptInterface
        fun markActive(day: String) {
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("lastActive", day).apply()
        }

        /** Pide el permiso de notificaciones en Android 13 o superior. */
        @JavascriptInterface
        fun requestNotifications() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
                }
            }
        }
    }

    private fun iconData(d: android.graphics.drawable.Drawable): String {
        val size = 72
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        d.setBounds(0, 0, size, size)
        d.draw(canvas)
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        bmp.recycle()
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    companion object {
        const val PREFS = "enfoque"
        const val BG = 0xFF090C11.toInt()

        @Volatile
        var foreground = false
    }
}
