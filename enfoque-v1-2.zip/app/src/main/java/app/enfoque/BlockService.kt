package app.enfoque

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * Servicio de accesibilidad: cuando se abre una app elegida durante una sesión de enfoque
 * (o dentro del horario de bloqueo), trae Enfoque al frente y la página muestra el aviso.
 */
class BlockService : AccessibilityService() {

    private var lastBounce = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        val prefs = getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        val nowMs = System.currentTimeMillis()
        var reason = ""
        var until = 0L

        // 1) Sesión de enfoque en curso
        val endAt = prefs.getLong("endAt", 0L)
        if (endAt > nowMs) {
            val inSession = try {
                has(JSONArray(prefs.getString("pkgs", "[]")), pkg)
            } catch (e: Exception) {
                false
            }
            if (inSession) {
                reason = "session"
                until = endAt
            }
        }

        // 2) Horario de bloqueo
        if (reason.isEmpty()) {
            val sched = prefs.getString("sched", null)
            if (sched != null) {
                try {
                    val o = JSONObject(sched)
                    if (o.optBoolean("on", false) && has(o.optJSONArray("pkgs"), pkg)) {
                        val u = scheduleUntil(o, nowMs)
                        if (u > 0L) {
                            reason = "schedule"
                            until = u
                        }
                    }
                } catch (e: Exception) {
                }
            }
        }
        if (reason.isEmpty()) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastBounce < 1000) return
        lastBounce = now

        val intent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra("blocked", pkg)
            .putExtra("reason", reason)
            .putExtra("until", until)
        startActivity(intent)
    }

    private fun has(arr: JSONArray?, pkg: String): Boolean {
        if (arr == null) return false
        for (i in 0 until arr.length()) {
            if (arr.optString(i) == pkg) return true
        }
        return false
    }

    /** Devuelve la hora de fin del horario si está activo ahora; si no, 0. */
    private fun scheduleUntil(o: JSONObject, nowMs: Long): Long {
        val from = o.optInt("from", 0)
        val to = o.optInt("to", 0)
        val days = o.optJSONArray("days") ?: return 0L
        if (from == to) return 0L

        val cal = Calendar.getInstance()
        cal.timeInMillis = nowMs
        val today = cal.get(Calendar.DAY_OF_WEEK) - 1
        val mins = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)

        var dayOk = false
        for (i in 0 until days.length()) {
            if (days.optInt(i, -1) == today) dayOk = true
        }
        if (!dayOk) return 0L

        val active = if (from < to) (mins >= from && mins < to) else (mins >= from || mins < to)
        if (!active) return 0L

        val end = Calendar.getInstance()
        end.timeInMillis = nowMs
        end.set(Calendar.HOUR_OF_DAY, to / 60)
        end.set(Calendar.MINUTE, to % 60)
        end.set(Calendar.SECOND, 0)
        end.set(Calendar.MILLISECOND, 0)
        if (from > to && mins >= from) end.add(Calendar.DAY_OF_MONTH, 1)
        return end.timeInMillis
    }

    override fun onInterrupt() {}
}
