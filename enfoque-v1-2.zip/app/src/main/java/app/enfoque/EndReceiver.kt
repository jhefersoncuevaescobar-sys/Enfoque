package app.enfoque

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Muestra el aviso "sesión completada" cuando suena la alarma y la app no está en pantalla. */
class EndReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (MainActivity.foreground) return

        val title = intent.getStringExtra("title") ?: "Enfoque"
        val text = intent.getStringExtra("text") ?: ""

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Fin de sesión", NotificationManager.IMPORTANCE_HIGH)
        )

        val open = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val n = Notification.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(1, n)
    }

    companion object {
        const val CHANNEL = "enfoque_fin"
    }
}
