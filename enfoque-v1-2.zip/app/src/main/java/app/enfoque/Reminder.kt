package app.enfoque

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

/** Programa (o cancela) el próximo recordatorio diario según lo guardado en las preferencias. */
object Reminder {

    private const val REQUEST = 9

    fun schedule(ctx: Context) {
        val prefs = ctx.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            ctx, REQUEST, Intent(ctx, ReminderReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        if (!prefs.getBoolean("remindOn", false)) {
            am.cancel(pi)
            return
        }
        val at = prefs.getInt("remindAt", 19 * 60)
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, at / 60)
        cal.set(Calendar.MINUTE, at % 60)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis() + 60000L) {
            cal.add(Calendar.DAY_OF_MONTH, 1)
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }
}
