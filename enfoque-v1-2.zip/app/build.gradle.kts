plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.enfoque"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.enfoque"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "1.2"
    }

    // Llave fija: así cada versión nueva se instala encima de la anterior sin perder tu progreso.
    signingConfigs {
        create("fija") {
            storeFile = file("enfoque.keystore")
            storePassword = "enfoque123"
            keyAlias = "enfoque"
            keyPassword = "enfoque123"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fija")
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
