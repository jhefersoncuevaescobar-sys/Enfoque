# Enfoque (Android)

App de concentración con retos diarios, puntos, medallas, consejos y bloqueo real de las apps que elijas durante la sesión de enfoque.

## Cómo funciona
- La interfaz está en `app/src/main/assets/index.html` y se muestra dentro de un WebView.
- `MainActivity.kt` lista las apps instaladas y se comunica con la interfaz.
- `BlockService.kt` es un servicio de accesibilidad: si abres una app elegida durante una sesión, trae Enfoque al frente y muestra el aviso de bloqueo. No lee el contenido de la pantalla.

## Compilar sin computadora (GitHub)
1. Crea un repositorio público en github.com.
2. Sube `enfoque-android.zip` a la raíz del repositorio (Add file > Upload files).
3. Crea el archivo `.github/workflows/build.yml` con el contenido que te dio Claude.
4. En la pestaña Actions espera a que termine; el APK queda en Releases > Enfoque (APK).

## Compilar con Android Studio
Abre esta carpeta y ejecuta `Build > Build APK`.

## Después de instalar
1. Permite instalar apps desconocidas al navegador con el que descargaste el APK.
2. Abre Enfoque y toca "Activar bloqueo".
3. En Ajustes de accesibilidad, abre Enfoque y actívalo. Si aparece gris: Ajustes > Apps > Enfoque > tres puntos > "Permitir ajustes restringidos".

## Novedades de la versión 1.1
- Estadísticas de la semana (minutos por día, sesiones y mejor racha) en la pestaña Logros.
- Aviso en la barra de notificaciones al terminar una sesión o un descanso.
- Horario de bloqueo automático por horas y días, sin iniciar una sesión.
- Más medallas y retos, y retos propios que se repiten cada día.
- Modo Pomodoro: descanso de 5 minutos tras cada sesión y de 15 cada 4.
- Modo estricto: no se puede pausar ni terminar antes de tiempo, y el bloqueo sigue aunque cierres la app.
- Llave de firma fija (`app/enfoque.keystore`): las versiones nuevas se instalan encima de la anterior sin perder el progreso. La contraseña está en `app/build.gradle.kts`; si algún día publicas la app de verdad, genera una llave propia y privada.

## Novedades de la versión 1.2
- Pestaña Hábitos: crea tus propios hábitos (nombre, duración e icono) y toca ▶ para empezar su temporizador. No se bloquea nada.
- Bosque: cada sesión o hábito completado planta un árbol; si abandonas, el árbol se seca.
- Meta diaria con anillo de progreso (30, 45, 60, 90 o 120 minutos, se cambia tocando la tarjeta).
- Recordatorio diario a la hora que elijas (pestaña Logros). No avisa si ya hiciste algo ese día.
- 4 medallas nuevas y retos diarios de hábitos.
